<?php
// Daily AI health check: verifies Groq models are still valid, auto-repairs config if not.
// Protected by token (?token=...). Logs to health.log. Never outputs key values.
header("Content-Type: text/plain; charset=utf-8");
if (!isset($_GET["token"]) || $_GET["token"] !== "3e69a9732ae696db606308cae4f2492b") {
    http_response_code(403); exit("Forbidden");
}
$log = __DIR__ . "/health.log";
// Capped logging: health.log never exceeds 200 lines (5GB protection).
function hc_log($log, $msg) {
    @file_put_contents($log, $msg, FILE_APPEND);
    $lines = @file($log, FILE_IGNORE_NEW_LINES);
    if (is_array($lines) && count($lines) > 200) {
        @file_put_contents($log, implode("\n", array_slice($lines, -200)) . "\n", LOCK_EX);
    }
}
$stamp = gmdate("Y-m-d H:i:s");
$out = "[$stamp] ";
require_once __DIR__ . "/zero-upgrades-lib.php";

$cfgFile = __DIR__ . "/config.php";
if (!file_exists($cfgFile)) { $out .= "ERROR config.php missing\n"; hc_log($log, $out); echo $out; exit; }
$cfg = include $cfgFile;
$groqKey = ""; $groqModels = []; $groqIdx = -1;
foreach ($cfg["providers"] as $i => $p) {
    if (strtolower($p["name"]) === "groq") {
        $groqKey = trim($p["key"]); $groqModels = $p["models"]; $groqIdx = $i; break;
    }
}
if (!$groqKey || $groqIdx < 0) { $out .= "ERROR no groq provider\n"; hc_log($log, $out); echo $out; exit; }

// Get live model list
$ch = curl_init("https://api.groq.com/openai/v1/models");
curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true,
    CURLOPT_HTTPHEADER=>["Authorization: Bearer ".$groqKey], CURLOPT_TIMEOUT=>20]);
$resp = curl_exec($ch); $http = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
if ($http !== 200) { $out .= "WARN models list HTTP $http (key may be invalid)\n"; hc_log($log, $out); echo $out; exit; }
$d = json_decode($resp, true);
$live = [];
if (isset($d["data"])) foreach ($d["data"] as $m) $live[] = $m["id"];
// Filter to chat models (skip whisper/audio)
$liveChat = array_values(array_filter($live, function($id){
    return stripos($id,"whisper")===false && stripos($id,"tts")===false;
}));

// Check configured models
$dead = [];
foreach ($groqModels as $m) if (!in_array($m, $live)) $dead[] = $m;

if (empty($dead)) {
    $out .= "OK all ".count($groqModels)." groq models alive\n";
} else {
    $out .= "DEAD models: ".implode(",", $dead)." — repairing. ";
    // Pick replacements: prefer gpt-oss-120b, then 20b, then first available chat models
    $prefs = ["openai/gpt-oss-120b","openai/gpt-oss-20b"];
    $new = [];
    foreach ($prefs as $pm) if (in_array($pm,$liveChat)) $new[] = $pm;
    foreach ($liveChat as $lm) { if (count($new)>=2) break; if (!in_array($lm,$new)) $new[]=$lm; }
    if (empty($new)) { $out .= "ERROR no replacement models available\n"; }
    else {
        $cfg["providers"][$groqIdx]["models"] = $new;
        // Owner revert support: back up the working config before overwriting.
        // Keeps the last 3 backups; older ones are pruned.
        $ts = time();
        @copy($cfgFile, __DIR__ . "/config.backup." . $ts . ".php");
        $all = [];
        foreach (glob(__DIR__ . "/config.backup.*.php") ?: [] as $bf) {
            $all[] = $bf;
        }
        if (!empty($all)) {
            rsort($all);
            foreach (array_slice($all, 3) as $old) { @unlink($old); }
        }
        $written = file_put_contents($cfgFile, "<?php\nreturn ".var_export($cfg,true).";\n");
        $out .= ($written!==false ? "FIXED → ".implode(",",$new) : "ERROR write failed");
        if ($written !== false) {
            zu_log("models", "Swapped dead model(s) ".implode(",", $dead)." for ".implode(",", $new).". Zero healed itself. (backup ts ".$ts.")");
        }
    }
    $out .= "\n";
}
hc_log($log, $out);
echo $out . "Done.\n";
