<?php
// Zero Sidekick panel token — server include only. Direct web access outputs nothing.
// >>> SET YOUR OWN RANDOM TOKEN HERE - never commit the real token <<<
return "REPLACE-WITH-YOUR-OWN-RANDOM-TOKEN";
