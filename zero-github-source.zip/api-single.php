<?php
// Zero Single Model API: one model call. Used by frontend for parallel ensemble.
// POST {messages:[...], model:"...", temp:0.7, provider:"groq"|"pollinations"|"cerebras"|"openrouter"|"mistral"|"gemini"}
header("Content-Type: application/json; charset=utf-8");
require __DIR__ . "/guard.php";
if ($_SERVER["REQUEST_METHOD"] !== "POST") { echo json_encode(["error"=>"Use POST."]); exit; }

$cfg = include __DIR__ . "/config.php";
$input = json_decode(file_get_contents("php://input"), true);
$messages = isset($input["messages"]) && is_array($input["messages"]) ? $input["messages"] : [];
$model = isset($input["model"]) ? trim($input["model"]) : "openai/gpt-oss-20b";
$temp = isset($input["temp"]) ? floatval($input["temp"]) : 0.7;
// Optional max_tokens override (clamped); lets the synthesis pass request room for complete answers
$maxT = isset($input["max_tokens"]) ? intval($input["max_tokens"]) : 1200;
if ($maxT < 100) $maxT = 100; if ($maxT > 3000) $maxT = 3000;
// Smart temperature: detect query type for optimal setting
$lastUser = "";
foreach (array_reverse($messages) as $m) {
    if (($m["role"]??"")==="user") { $lastUser = is_string($m["content"]) ? $m["content"] : ""; break; }
}
if (!isset($input["temp"])) {
    if (preg_match('/^\s*(what is|who is|when|where|how many|calculate|solve|\d+\s*[+\-*\/])/i', $lastUser)) $temp = 0.3;
    elseif (preg_match('/write|create|generate|story|poem|code/i', $lastUser)) $temp = 0.7;
    else $temp = 0.5;
}
$provider = isset($input["provider"]) ? trim($input["provider"]) : "groq";
if (empty($messages)) { echo json_encode(["error"=>"No messages."]); exit; }

function getKey($cfg, $name){
    foreach ($cfg["providers"] as $p) {
        if (strtolower($p["name"]) === strtolower($name)) return trim($p["key"]);
    }
    return "";
}

$url = ""; $headers = ["Content-Type: application/json"];

switch ($provider) {
    case "pollinations":
        $url = "https://text.pollinations.ai/openai/chat/completions";
        break;
    case "cerebras":
        $key = getKey($cfg, "cerebras");
        if ($key === "") { echo json_encode(["error"=>"No key."]); exit; }
        $url = "https://api.cerebras.ai/v1/chat/completions";
        $headers[] = "Authorization: Bearer ".$key;
        break;
    case "openrouter":
        $key = getKey($cfg, "openrouter");
        if ($key === "") { echo json_encode(["error"=>"No key."]); exit; }
        $url = "https://openrouter.ai/api/v1/chat/completions";
        $headers[] = "Authorization: Bearer ".$key;
        $headers[] = "HTTP-Referer: https://zero.page.gd";
        $headers[] = "X-Title: Zero";
        break;
    case "mistral":
        $key = getKey($cfg, "mistral");
        if ($key === "") { echo json_encode(["error"=>"No key."]); exit; }
        $url = "https://api.mistral.ai/v1/chat/completions";
        $headers[] = "Authorization: Bearer ".$key;
        break;
    case "gemini":
        $key = getKey($cfg, "gemini");
        if ($key === "") { echo json_encode(["error"=>"No key."]); exit; }
        $url = "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions";
        $headers[] = "Authorization: Bearer ".$key;
        break;
    case "groq":
    default:
        $key = getKey($cfg, "groq");
        if ($key === "") { echo json_encode(["error"=>"No key."]); exit; }
        $url = "https://api.groq.com/openai/v1/chat/completions";
        $headers[] = "Authorization: Bearer ".$key;
        break;
}

$ch = curl_init($url);
curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true, CURLOPT_POST=>true,
    CURLOPT_POSTFIELDS=>json_encode(["model"=>$model,"messages"=>$messages,"temperature"=>$temp,"max_tokens"=>$maxT]),
    CURLOPT_HTTPHEADER=>$headers, CURLOPT_TIMEOUT=>30]);
$resp = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlErr = curl_error($ch);
curl_close($ch);
$d = json_decode($resp, true);
if (isset($d["choices"][0]["message"]["content"])) {
    echo json_encode(["answer"=>trim($d["choices"][0]["message"]["content"])]);
} else {
    // Diagnostic info only (never keys): distinguishes rate limits (429)
    // from retired models (404/400) from network failures (curl error), so
    // the next "couldn't reach its AI models" can be fixed without guessing.
    $diag = ["error"=>"Model failed.", "http"=>$httpCode];
    if ($curlErr !== "") { $diag["curl"] = substr($curlErr, 0, 120); }
    elseif (is_string($resp) && $resp !== "") {
        $rd = json_decode($resp, true);
        if (isset($rd["error"])) {
            // Scrub key-like fragments in case a provider ever mirrors the
            // key in its error body (prefixes like gsk_, sk-, sk-or-, or any
            // long credential-shaped token) before handing it to the client.
            $pErr = substr(json_encode($rd["error"]), 0, 200);
            $pErr = preg_replace('/\b(gsk_|sk-|sk-or-|Bearer\s+)[A-Za-z0-9_\-\.]{8,}/i', '$1[redacted]', $pErr);
            $pErr = preg_replace('/[A-Za-z0-9_\-]{24,}/', '[redacted]', $pErr);
            $diag["provider"] = $pErr;
        }
    }
    echo json_encode($diag);
}
