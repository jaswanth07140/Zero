# Zero

Zero is a fast, friendly AI-powered search engine with AI answers, maps, and apps. Free, no sign-up required.

**Live site:** https://zero.page.gd/

## Features

- **Zero Search** — Multi-source web search with relevance ranking (keyless sources first)
- **Zero AI** — Chat with AI models that confer and answer as one, with web grounding and cited sources
- **ZMaps** — Maps with place search and turn-by-turn directions (Leaflet + OSM, no API key needed)
- **ZeroTube** — YouTube-style video browsing via Piped/Invidious
- **Zero Mail** — Gmail send-only integration (user-authorized, review before send)
- **Zero Message** — End-to-end encrypted messaging (AES-GCM)
- **Study Notebooks** — Lessons, flashcards, quizzes with progress tracking
- **Zero Sidekick** — Companion Chrome extension (see `/zero-sidekick`)

## Tech

- Plain PHP backend + vanilla JS frontend. No build step, no framework.
- Hosted on InfinityFree (free tier).
- AI via free provider APIs (Groq, Cerebras, OpenRouter, Mistral, Pollinations).

## Setup

1. Upload the files to any PHP host (document root).
2. Copy `config.php.example` to `config.php` and add your own free API keys.
3. Set your own random keys in `owner-secret.php` and `panel-token.php`.
4. Never commit `config.php`, `owner-secret.php`, or `panel-token.php` with real secrets.

## Security notes

- `guard.php` rate-limits all public API endpoints (120 req/min per IP).
- `config.php` is blocked from direct web access via `.htaccess`.
- See the inline comments in `guard.php` and `zero-auth.php` for the auth model.
