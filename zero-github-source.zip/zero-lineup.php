<?php
// Zero live AI lineup: lets the frontend self-update its model ensemble.
// GET only. Outputs provider NAMES + MODEL NAMES only — never keys or secrets.
// Guarded: same-origin + rate limited like every other endpoint.
header("Content-Type: application/json; charset=utf-8");
require __DIR__ . "/guard.php";
if (($_SERVER["REQUEST_METHOD"] ?? "") !== "GET") {
    http_response_code(405);
    echo json_encode(["ok" => false, "error" => "Use GET."]);
    exit;
}
$cfgFile = __DIR__ . "/config.php";
if (!is_file($cfgFile)) {
    http_response_code(500);
    echo json_encode(["ok" => false, "error" => "No config."]);
    exit;
}
$cfg = include $cfgFile;
$lineup = [];
if (isset($cfg["providers"]) && is_array($cfg["providers"])) {
    foreach ($cfg["providers"] as $p) {
        if (!is_array($p) || empty($p["name"])) continue;
        $models = [];
        if (isset($p["models"]) && is_array($p["models"])) {
            foreach ($p["models"] as $m) {
                $m = trim((string)$m);
                if ($m !== "") $models[] = $m;
            }
        }
        // Deliberately only name + models. Keys and all other fields stay server-side.
        $lineup[] = ["provider" => (string)$p["name"], "models" => array_values($models)];
    }
}
echo json_encode(["ok" => true, "lineup" => $lineup, "ts" => time()]);
