<?php
// Owner master key for zero-upgrades.php actions (revert / kill / revive) and owner.php.
// Direct web access outputs nothing. Included server-side only.
// >>> SET YOUR OWN RANDOM KEY HERE - never commit the real key <<<
return "REPLACE-WITH-YOUR-OWN-RANDOM-KEY";
