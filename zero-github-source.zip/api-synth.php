<?php
// Zero Synthesis API: combines multiple model answers into ONE.
// POST {messages:[...], responses:["...", ...]}
header("Content-Type: application/json; charset=utf-8");
require __DIR__ . "/guard.php";
if ($_SERVER["REQUEST_METHOD"] !== "POST") { echo json_encode(["error"=>"Use POST."]); exit; }

$cfg = include __DIR__ . "/config.php";
$input = json_decode(file_get_contents("php://input"), true);
$messages = isset($input["messages"]) && is_array($input["messages"]) ? $input["messages"] : [];
$responses = isset($input["responses"]) && is_array($input["responses"]) ? $input["responses"] : [];
if (empty($responses)) { echo json_encode(["error"=>"No responses."]); exit; }
if (count($responses) === 1) { echo json_encode(["answer"=>$responses[0],"sources"=>[],"ensemble_count"=>1]); exit; }

$groqKey = ""; $tavilyKey = isset($cfg["tavily_key"]) ? trim($cfg["tavily_key"]) : "";
foreach ($cfg["providers"] as $p) {
    if (strtolower($p["name"]) === "groq") $groqKey = trim($p["key"]);
}

// Web search for live context (if enabled)
$searchCtx = ""; $sources = [];
if (!empty($cfg["web_search"]) && $tavilyKey !== "") {
    $lastQ = "";
    for ($i=count($messages)-1; $i>=0; $i--) {
        if (($messages[$i]["role"]??"")==="user") { $lastQ = $messages[$i]["content"]; break; }
    }
    if ($lastQ !== "") {
        $ch = curl_init("https://api.tavily.com/search");
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true, CURLOPT_POST=>true,
            CURLOPT_POSTFIELDS=>json_encode(["api_key"=>$tavilyKey,"query"=>$lastQ,"max_results"=>5,"include_answer"=>false]),
            CURLOPT_HTTPHEADER=>["Content-Type: application/json"], CURLOPT_TIMEOUT=>10]);
        $sr = curl_exec($ch); curl_close($ch);
        $sd = json_decode($sr, true);
        if (isset($sd["results"]) && is_array($sd["results"])) {
            $searchCtx = "\n\nLive web results:\n";
            foreach (array_slice($sd["results"],0,5) as $r) {
                $searchCtx .= "- ".($r["title"]??"").": ".substr($r["content"]??"",0,300)."\n";
                $sources[] = ["title"=>$r["title"]??"", "url"=>$r["url"]??""];
            }
        }
    }
}

// Synthesize
$synthPrompt = "You are Zero, an elite AI assistant. You are synthesizing answers from ".count($responses)." AI models into ONE superior answer.\n".
    "Think like Claude and the best AI assistants: be brilliant, precise, and genuinely helpful.\n".
    "PRESENTATION (this matters as much as accuracy):\n".
    "Write answers as beautiful, well-structured documents. Use a clear title line for the topic when one fits.\n".
    "Break content into sections with ## section headers. Use numbered lists for steps, questions, or sequences; bullet lists for collections of points.\n".
    "Put key terms and section labels in **bold**. Keep paragraphs short. Never leave an answer half-finished: if the topic has natural parts (e.g. all quiz topics, all steps), cover ALL of them completely.\n".
    "RULES:\n".
    "1. Combine into ONE accurate, well-written answer that is BETTER than any single model response.\n".
    "2. Resolve contradictions by majority; if models disagree significantly, note the uncertainty briefly.\n".
    "3. For math/calculations: give just the result clearly, show steps only if complex.\n".
    "4. For 'who is/was': lead with key facts (who, known for, key dates).\n".
    "5. For 'how to': clear numbered steps, practical and specific.\n".
    "6. For definitions: meaning first, then brief context or example.\n".
    "7. For coding: CLEAN, well-commented code with descriptive names. Use ```language blocks.\n".
    "8. For comparisons: use clear structure (pros/cons or side-by-side).\n".
    "9. For opinions/advice: give a real, thoughtful answer with reasoning, not hedging.\n".
    "10. If web results provided, prefer their factual claims for current events/dates.\n".
    "11. Never mention the models or synthesis. Just answer as Zero.\n".
    "12. Match the user's language and tone. Be direct, no fluff, no filler phrases.\n".
    "13. Structure longer answers with headers or bullets for readability.\n".
    "14. NEVER output raw HTML tags like <br>, <div>, <p> - use plain markdown only.\n\n";
foreach ($responses as $i => $r) $synthPrompt .= "--- Model ".($i+1)." ---\n".substr($r,0,2500)."\n\n";
if ($searchCtx !== "") $synthPrompt .= $searchCtx."\n\n";
$synthPrompt .= "Final synthesized answer:";

$ch = curl_init("https://api.groq.com/openai/v1/chat/completions");
curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true, CURLOPT_POST=>true,
    CURLOPT_POSTFIELDS=>json_encode(["model"=>"openai/gpt-oss-120b",
        "messages"=>[["role"=>"user","content"=>$synthPrompt]],"max_tokens"=>2000,"temperature"=>0.3]),
    CURLOPT_HTTPHEADER=>["Content-Type: application/json","Authorization: Bearer ".$groqKey],
    CURLOPT_TIMEOUT=>25]);
$sr = curl_exec($ch); curl_close($ch);
$sd = json_decode($sr, true);
$final = isset($sd["choices"][0]["message"]["content"]) ? trim($sd["choices"][0]["message"]["content"]) : $responses[0];
// Quality check: if synthesis failed or is too short, use the longest quality response
if (strlen($final) < 20 && count($responses) > 1) {
    usort($responses, function($a, $b) { return strlen($b) - strlen($a); });
    $final = $responses[0];
}

echo json_encode(["answer"=>$final,"sources"=>$sources,"ensemble_count"=>count($responses)]);
